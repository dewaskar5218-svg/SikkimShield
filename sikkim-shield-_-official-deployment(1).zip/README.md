
# 🏔 Sikkim Shield: Premium Vehicle Security

Sikkim Shield is a high-performance vehicle security and monitoring platform engineered specifically for the rugged terrain and unique needs of Sikkim. Built with React and powered by the Gemini AI for real-time surveillance analysis.

![Sikkim Shield App](https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&q=80&w=1000)

## ✨ Features

- **Himalayan Terrain Optimization**: Specifically designed for locations like Gangtok, Namchi, and Pelling.
- **AI-Powered Surveillance**: Real-time image analysis of vehicle surroundings using Gemini 3 Flash.
- **Progressive Web App (PWA)**: Installable on Android and iOS devices directly from the browser.
- **Flexible EMI Options**: Instant AI-calculated financing plans (3, 6, and 12 months).
- **Satellite Tracking**: Live GPS monitoring with dual-relay support for mountain dead zones.

## 🚀 Deployment

### GitHub Pages (Web)
1. Push this code to a GitHub repository.
2. Go to **Settings > Pages**.
3. Select the `main` branch as the source.
4. Enable HTTPS.

### Android Play Store (App)
1. Go to [PWABuilder.com](https://www.pwabuilder.com/).
2. Paste your GitHub Pages URL.
3. Click **"Package for Store"** and select **Android**.
4. Download the `.aab` (Android App Bundle).
5. Upload the bundle to the [Google Play Console](https://play.google.com/console/).

## 🛠 Tech Stack

- **Framework**: React 19 (No-build ESM setup)
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **AI Engine**: Google Gemini API
- **PWA**: Web Manifest & Service Workers

## 📝 License
Proprietary for Sikkim Shield Security Systems. All Rights Reserved.
